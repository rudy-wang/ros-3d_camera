#include <iterator>
#include <iostream>
#include <sstream>
#include <cmath>
#include <vector>
#include <functional>
#include <time.h>
#include <omp.h>

#include <ros/ros.h>

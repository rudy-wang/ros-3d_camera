var a00152 =
[
    [ "compute_weight", "a00114.html", "a00114" ],
    [ "FVCoeff", "a00152.html#a890a4982bf3d671dd4b56e12420ae211", null ],
    [ "init", "a00152.html#a6baf592990b0e39b6f719e702b7e85e3", null ],
    [ "operator()", "a00152.html#accfd72c1eea4cf341f7c056e7d70f738", null ],
    [ "weights_", "a00152.html#a3339bef1ec36d34fc18dd4011b570868", null ]
];
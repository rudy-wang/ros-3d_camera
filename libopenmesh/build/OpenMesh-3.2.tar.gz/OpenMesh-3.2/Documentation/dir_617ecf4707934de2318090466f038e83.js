var dir_617ecf4707934de2318090466f038e83 =
[
    [ "Composite", "dir_3cde2ca7af9740c5b0d23b8cc04dfa69.html", "dir_3cde2ca7af9740c5b0d23b8cc04dfa69" ],
    [ "CatmullClarkT.hh", "a00565.html", [
      [ "CatmullClarkT", "a00098.html", "a00098" ]
    ] ],
    [ "CompositeLoopT.hh", "a00566.html", [
      [ "CompositeLoopT", "a00107.html", "a00107" ],
      [ "EVCoeff", "a00137.html", "a00137" ],
      [ "compute_weight", "a00113.html", "a00113" ]
    ] ],
    [ "CompositeSqrt3T.hh", "a00567.html", [
      [ "CompositeSqrt3T", "a00108.html", "a00108" ],
      [ "FVCoeff", "a00152.html", "a00152" ],
      [ "compute_weight", "a00114.html", "a00114" ]
    ] ],
    [ "LongestEdgeT.hh", "a00568.html", [
      [ "CompareLengthFunction", "a00106.html", "a00106" ],
      [ "LongestEdgeT", "a00183.html", "a00183" ]
    ] ],
    [ "LoopT.hh", "a00569.html", "a00569" ],
    [ "ModifiedButterFlyT.hh", "a00570.html", [
      [ "ModifiedButterflyT", "a00205.html", "a00205" ]
    ] ],
    [ "Sqrt3InterpolatingSubdividerLabsikGreinerT.hh", "a00571.html", "a00571" ],
    [ "Sqrt3T.hh", "a00572.html", "a00572" ],
    [ "SubdividerT.hh", "a00573.html", "a00573" ]
];
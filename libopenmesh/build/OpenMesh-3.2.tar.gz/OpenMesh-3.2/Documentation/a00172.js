var a00172 =
[
    [ "get_heap_position", "a00172.html#a21d249ef7e9a185e92d2774f9fe43616", null ],
    [ "greater", "a00172.html#a86ba29c86c9189b6394fb154932b52e7", null ],
    [ "less", "a00172.html#ae246f6c4f57df712acd35b0288e29aff", null ],
    [ "set_heap_position", "a00172.html#adcce753277a5a14d36b038b412a9de6c", null ]
];
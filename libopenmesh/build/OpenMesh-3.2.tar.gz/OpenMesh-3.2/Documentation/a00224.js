var a00224 =
[
    [ "value_type", "a00224.html#a36588a8b1c74d29e1fe3545a9667a16d", null ],
    [ "vector_type", "a00224.html#af98a68626c2c4530a6a3d8db7ab0e596", null ],
    [ "Plane3d", "a00224.html#a717688d688dda94cfe69c96622d00ac7", null ],
    [ "Plane3d", "a00224.html#a932327b391a56d9fc792fcfcf8339ee0", null ],
    [ "signed_distance", "a00224.html#ac8e6e0da9b231169005263b3c23303e9", null ],
    [ "singed_distance", "a00224.html#a10c9be4fbd0692768eeca2dd5739adb9", null ],
    [ "d_", "a00224.html#ac43866a66a76184863c47d9aef94bf0b", null ],
    [ "n_", "a00224.html#a48d342a7b8f1207b70831af6697c7bd8", null ]
];
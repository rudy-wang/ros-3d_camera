var a00461 =
[
    [ "AttributeBits", "a00461.html#ab78a93560926cd2f9958cb028f7ea96d", [
      [ "None", "a00461.html#ab78a93560926cd2f9958cb028f7ea96dabf5f773fefa8a6aa2c4b56158de44b92", null ],
      [ "Normal", "a00461.html#ab78a93560926cd2f9958cb028f7ea96da213616dd2e4d9744d863587001a77988", null ],
      [ "Color", "a00461.html#ab78a93560926cd2f9958cb028f7ea96dad51534b15e5d0f65569251f4cb3c0d0c", null ],
      [ "PrevHalfedge", "a00461.html#ab78a93560926cd2f9958cb028f7ea96dafaaebe1808b5cce96ad4e19df471d58a", null ],
      [ "Status", "a00461.html#ab78a93560926cd2f9958cb028f7ea96dad3e94e10c76894ebce6048b8bbb77a74", null ],
      [ "TexCoord1D", "a00461.html#ab78a93560926cd2f9958cb028f7ea96da361fe12954663bc16ce085e98fecce20", null ],
      [ "TexCoord2D", "a00461.html#ab78a93560926cd2f9958cb028f7ea96da358ce33062ef8be1f9928f9197c29ad1", null ],
      [ "TexCoord3D", "a00461.html#ab78a93560926cd2f9958cb028f7ea96da80d64ca7366a1bfa3c21dab475dc2f28", null ],
      [ "TextureIndex", "a00461.html#ab78a93560926cd2f9958cb028f7ea96da0405f2e3d62fa43d7c912d6fb78e29cd", null ]
    ] ]
];
var a00202 =
[
    [ "Base", "a00202.html#a204d0fcac0fd209b1c7dc80546d7c074", null ],
    [ "CollapseInfo", "a00202.html#a97a335d3e836fed91982017de0354bdb", null ],
    [ "Handle", "a00202.html#a743c66317c69025676bae958245e77b2", null ],
    [ "Mesh", "a00202.html#a71e8766d0f5b1ae85743f6422f349e6d", null ],
    [ "Self", "a00202.html#a840742d97a803f25115d9efa289d049f", null ],
    [ "ModEdgeLengthT", "a00202.html#a64dacb1c6889dc21b25b8df488fc6cf6", null ],
    [ "collapse_priority", "a00202.html#a8b205feac99470a63e6c3351088513a0", null ],
    [ "edge_length", "a00202.html#ae26d4f819beb5de19fbef2f84252e0e7", null ],
    [ "name", "a00202.html#a1ab66d0f42f27a8e779c6f1b1588040c", null ],
    [ "set_edge_length", "a00202.html#a580332f89d81f58dabd937e25096d5a0", null ],
    [ "set_error_tolerance_factor", "a00202.html#a50454bc8ea7dd04451def96d6e447654", null ]
];